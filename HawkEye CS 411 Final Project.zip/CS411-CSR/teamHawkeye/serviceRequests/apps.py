from django.apps import AppConfig


class ServicerequestsConfig(AppConfig):
    name = 'serviceRequests'