# Simple Django web app that's able to sync with the DB and handle users, profile pages, logins, logouts, and registration.
